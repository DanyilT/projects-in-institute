﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class NextStep : MonoBehaviour
{
    //private int previousSceneIndex = SceneManager.GetActiveScene().buildIndex - 1;
    private string sceneName = "Game";

    [SerializeField] public GameObject creditsModal;
    public bool creditsOpen = false;

    private AsyncOperation asyncOperation;

    private void Start()
    {
        creditsModal.SetActive(creditsOpen);
        StartCoroutine(PreloadNextScene());
    }

    IEnumerator PreloadNextScene()
    {
        asyncOperation = SceneManager.LoadSceneAsync(sceneName);
        asyncOperation.allowSceneActivation = false;
        yield return null;
    }

    public void OpenCreditsModal()
    {
        if (creditsOpen)
        {
            creditsOpen = false;
            creditsModal.SetActive(creditsOpen);
        }
        else
        {
            creditsOpen = true;
            creditsModal.SetActive(creditsOpen);
        }
    }

    public void GoBack()
    {
        if (creditsOpen)
        {
            creditsOpen = false;
            creditsModal.SetActive(creditsOpen);
        }
        else
        {
            ActivateNextScene();
        }
    }

    public void ActivateNextScene()
    {
        if (asyncOperation != null && !asyncOperation.allowSceneActivation)
        {
            asyncOperation.allowSceneActivation = true;
        }
    }
}
