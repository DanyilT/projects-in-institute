﻿using UnityEngine;
using UnityEngine.UI;

public class HandednessToggle : MonoBehaviour
{
    [SerializeField] private GameObject onToHide;
    [SerializeField] private GameObject offToHide;

    [SerializeField] private Toggle toggle;

    private void Start()
    {
        // Load user preference from PlayerPrefs, default to left-handed if not set
        string handedPreference = PlayerPrefs.GetString(ButtonPositionManager.navigationPreferenceKey, "Right");

        // Set toggle state based on user preference
        toggle.isOn = handedPreference == "Right";

        onToHide.SetActive(toggle.isOn);
        offToHide.SetActive(!toggle.isOn);

        // Subscribe to toggle value changed event
        toggle.onValueChanged.AddListener(OnToggleValueChanged);
    }

    private void OnToggleValueChanged(bool isRightHanded)
    {
        onToHide.SetActive(isRightHanded);
        offToHide.SetActive(!isRightHanded);

        string handedPreference = isRightHanded ? "Right" : "Left";

        // Save user preference to PlayerPrefs
        PlayerPrefs.SetString(ButtonPositionManager.navigationPreferenceKey, handedPreference);

        // Apply changes to all button prefabs in the scene
        ButtonPositionManager[] buttonManagers = FindObjectsOfType<ButtonPositionManager>();
        foreach (ButtonPositionManager manager in buttonManagers)
        {
            manager.SetButtonPositions(handedPreference);
        }
    }
}
