﻿using UnityEngine;

public class OpenURL : MonoBehaviour
{
    [SerializeField] private string urlOnBuyMeACoffee = "https://www.buymeacoffee.com/DanyT"; // The URL to open in a web browser
    [SerializeField] private string urlOnComeBackAvile = "https://savelife.in.ua/en/"; // The URL to open in a web browser
    [SerializeField] private string urlOnAppInGooglePlay = "#"; // The URL to open in a web browser
    [SerializeField] private string urlOnTestingForm = "https://yo2aqdvjya1.typeform.com/to/lt7dIQwd"; // The URL to open in a web browser

    public void OpenURLOnByMeACoffee()
    {
        // Open the URL in a web browser
        Application.OpenURL(urlOnBuyMeACoffee);
    }

    public void OpenURLOnComeBackAvile()
    {
        // Open the URL in a web browser
        Application.OpenURL(urlOnComeBackAvile);
    }

    public void OpenURLOnAppInGooglePlay()
    {
        // Open the URL in a web browser
        Application.OpenURL(urlOnAppInGooglePlay);
    }

    public void OpenURLOnTestingForm()
    {
        // Open the URL in a web browser
        Application.OpenURL(urlOnTestingForm);
    }
}
