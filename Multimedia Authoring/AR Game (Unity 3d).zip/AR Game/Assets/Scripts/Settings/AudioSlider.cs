﻿using UnityEngine;
using UnityEngine.UI;

public class AudioSlider : MonoBehaviour
{
    public Slider SoundEffectsVolumeSlider;
    public Slider MusicVolumeSlider;

    private AudioManager audioManager;

    void Start()
    {
        audioManager = AudioManager.Instance;

        SoundEffectsVolumeSlider.value = PlayerPrefs.GetFloat("SoundEffectsVolume", 0.5f);
        SoundEffectsVolumeSlider.onValueChanged.AddListener(OnSoundEffectsVolumeChanged);

        MusicVolumeSlider.value = PlayerPrefs.GetFloat("MusicVolume", 0.5f);
        MusicVolumeSlider.onValueChanged.AddListener(OnMusicVolumeChanged);
    }

    void OnSoundEffectsVolumeChanged(float volume)
    {
        audioManager.SetSoundEffectsVolume(volume);
    }

    void OnMusicVolumeChanged(float volume)
    {
        audioManager.SetMusicVolume(volume);
    }
}

