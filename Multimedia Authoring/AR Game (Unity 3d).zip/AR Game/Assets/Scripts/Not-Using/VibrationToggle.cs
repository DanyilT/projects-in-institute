﻿using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class VibrationToggle : MonoBehaviour
{
    [SerializeField] private GameObject onToHide; // Text 'On'
    [SerializeField] private GameObject offToHide; // Text 'Off'

    [SerializeField] private Toggle toggle;

    VibrationManager vibrationManager;

    // Use this for initialization
    void Start()
	{
        vibrationManager = VibrationManager.Instance;
        toggle.isOn = PlayerPrefs.GetInt("VibrationEnabled", 1) == 1;

        onToHide.SetActive(toggle.isOn);
        offToHide.SetActive(!toggle.isOn);

        // Subscribe to toggle value changed event
        toggle.onValueChanged.AddListener(OnToggleVibration);
    }

    public void OnToggleVibration(bool on)
    {
        onToHide.SetActive(on);
        offToHide.SetActive(!on);

        vibrationManager.vibrationEnabled = !vibrationManager.vibrationEnabled;

        PlayerPrefs.SetInt("VibrationEnabled", vibrationManager.vibrationEnabled ? 1 : 0);
    }
}
