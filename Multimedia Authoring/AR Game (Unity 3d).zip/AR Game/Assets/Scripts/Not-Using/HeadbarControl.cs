﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class HeadbarControl : MonoBehaviour
{

    private WebCamDevice frontCam;
    private WebCamTexture cameraTexture;
    public Text textObject;
    public GameObject buttonObject;
    private RectTransform rectTransform;

    void Start()
    {
        // Get the Text component of the object
        textObject = GetComponent<Text>();
        rectTransform = buttonObject.GetComponent<RectTransform>();

        WebCamDevice[] devices = WebCamTexture.devices;
        for (int i = 0; i < devices.Length; i++)
        {
            if (devices[i].isFrontFacing)
            {
                frontCam = devices[i];
                cameraTexture = new WebCamTexture(frontCam.name);
                GetComponent<Renderer>().material.mainTexture = cameraTexture;
                cameraTexture.Play();
                break;
            }
        }

        // Get the position of the front camera
        Vector3 cameraPos = Camera.main.WorldToScreenPoint(transform.position);

        // Change the alignment of the text based on the position of the camera
        if (cameraPos.x < Screen.width / 3)
        {
            // Camera is on the left
            textObject.alignment = TextAnchor.MiddleCenter;
        }
        else if (cameraPos.x > Screen.width * 2 / 3)
        {
            // Camera is on the right
            textObject.alignment = TextAnchor.MiddleRight;

            // Set the anchorMin and anchorMax to (0,1) to anchor the top-left corner
            rectTransform.anchorMin = new Vector2(0, 1);
            rectTransform.anchorMax = new Vector2(0, 1);

            // Set the pivot to (0,1) to align the RectTransform to the top-left corner
            rectTransform.pivot = new Vector2(0, 1);

            buttonObject.transform.position = new Vector3(0, 0, 0);
        }
        else
        {
            // Camera is in the center
            textObject.alignment = TextAnchor.MiddleLeft;
        }
    }
}
