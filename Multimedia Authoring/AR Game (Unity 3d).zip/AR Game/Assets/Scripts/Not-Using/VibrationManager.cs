﻿using UnityEngine;

public class VibrationManager : MonoBehaviour
{
    public static VibrationManager Instance;

    public bool vibrationEnabled;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }

        vibrationEnabled = PlayerPrefs.GetInt("VibrationEnabled", 1) == 1;
    }

    public void Vibrate()
    {
        if (vibrationEnabled)
        {
#if UNITY_ANDROID
            AndroidVibrate(100); // Set the desired duration in milliseconds
#endif

#if UNITY_IOS
            // Implement iOS vibration here if needed
#endif
        }
    }

#if UNITY_ANDROID
    private void AndroidVibrate(long milliseconds)
    {
        using (AndroidJavaClass vibrationPluginClass = new AndroidJavaClass("com.example.vibrationplugin.VibrationPlugin"))
        {
            using (AndroidJavaClass unityPlayerClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
            {
                using (AndroidJavaObject unityActivity = unityPlayerClass.GetStatic<AndroidJavaObject>("currentActivity"))
                {
                    vibrationPluginClass.CallStatic("vibrate", unityActivity, milliseconds);
                }
            }
        }
    }
#endif
}
