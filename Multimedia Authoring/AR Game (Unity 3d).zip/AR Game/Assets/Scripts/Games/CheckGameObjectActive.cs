﻿using UnityEngine;

public class CheckGameObjectActive : MonoBehaviour
{
    public GameObject scan;

    private GameObject ball, reset;

    private bool active;

    private void Start()
    {
        ball = GameObject.FindGameObjectWithTag("Ball");
        reset = GameObject.FindGameObjectWithTag("Reset");
        active = false;
        ball.SetActive(active);
    }
    private void Update()
    {
        reset.SetActive(!scan.activeInHierarchy);
        if (!scan.activeInHierarchy && !active)
        {
            active = true;
            ball.SetActive(active);
        }
    }
}
