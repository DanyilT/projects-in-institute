﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class RestartButton : MonoBehaviour
{
    public void Restart()
    {
        PlayerPrefs.SetInt("ScoreKey", 0);

        GameObject reset = GameObject.FindGameObjectWithTag("Reset");
        reset.GetComponent<Button>().onClick.Invoke();
    }
}
