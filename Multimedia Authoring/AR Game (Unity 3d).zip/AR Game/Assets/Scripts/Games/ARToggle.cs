﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;

public class ARToggle : MonoBehaviour
{
    public ARPlaneManager arPlaneManager;
	public ARSession arSession; // Reference to the ARSession component
    public GameObject arCamera; // Reference to the AR camera GameObject
    public GameObject arModeOnIcon; // The icon to show when AR mode is on
    public GameObject arModeOffIcon; // The icon to show when AR mode is off
    public List<GameObject> arObjects; // Array of GameObjects to activate/deactivate in AR mode

    private bool arModeEnabled; // Flag to track if AR mode is currently enabled

    GameObject[] ballObjects;
    GameObject reset;

    // Use this for initialization
    void Start()
	{
        arModeEnabled = true;

        // Find all GameObjects with the "Ball" and "Basket" tag
        ballObjects = GameObject.FindGameObjectsWithTag("Ball");
        reset = GameObject.FindGameObjectWithTag("Reset");

        // Add the found GameObjects to the list
        foreach (GameObject obj in ballObjects)
        {
            arObjects.Add(obj);
        }
        arObjects.Add(reset);

        if (GameObject.FindGameObjectWithTag("Basket") != null)
        {
            GameObject[] basketObjects = GameObject.FindGameObjectsWithTag("Basket");
            foreach (GameObject obj in basketObjects)
            {
                arObjects.Add(obj);
            }
        }

        // Enable/disable AR objects
        foreach (GameObject arObject in arObjects)
        {
            arObject.SetActive(arModeEnabled);
        }

        // Change button icon based on AR mode
        arModeOnIcon.SetActive(arModeEnabled);
        arModeOffIcon.SetActive(!arModeEnabled);
    }

    public void ToggleARMode()
    {
        arModeEnabled = !arModeEnabled; // Invert the AR mode flag

        // Enable/disable AR components
        //arSession.enabled = arModeEnabled;
        //arCamera.SetActive(arModeEnabled);
        arPlaneManager.enabled = arModeEnabled;

        if (GameObject.FindGameObjectWithTag("Basket") != null)
        {
            GameObject[] basketObjects = GameObject.FindGameObjectsWithTag("Basket");
            foreach (GameObject obj in basketObjects)
            {
                arObjects.Add(obj);
            }
        }

        // Enable/disable AR objects
        foreach (GameObject arObject in arObjects)
        {
            arObject.SetActive(arModeEnabled);
        }

        // Change button icon based on AR mode

        arModeOnIcon.SetActive(arModeEnabled);
        arModeOffIcon.SetActive(!arModeEnabled);
    }
}

