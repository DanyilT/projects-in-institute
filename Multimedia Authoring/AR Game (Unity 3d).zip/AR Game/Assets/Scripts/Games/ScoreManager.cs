﻿using UnityEngine;
using System.Collections;
using TMPro;
using System.Globalization;
using Unity.VisualScripting.Antlr3.Runtime;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    [SerializeField] private GameObject modalWithMaxScore;
    [SerializeField] private GameObject manual;

    [SerializeField] private TextMeshProUGUI maxScoreText;
    private bool show = false;

    private void Update()
	{
        gameObject.GetComponent<TextMeshProUGUI>().text = PlayerPrefs.GetInt("ScoreKey", 0) + "";

        if (PlayerPrefs.GetInt("ScoreKey") > PlayerPrefs.GetInt("MaxScoreKey", 0))
        {
            PlayerPrefs.SetInt("MaxScoreKey", PlayerPrefs.GetInt("ScoreKey", 0));
        }

        if (show)
        {
            maxScoreText.text = PlayerPrefs.GetInt("MaxScoreKey", 0) + "";
        }
    }

    public void ShowModal()
    {
        show = !show;
        modalWithMaxScore.SetActive(show);

        if (manual.activeInHierarchy && show)
        {
            GameObject manual = GameObject.FindGameObjectWithTag("Readme");
            manual.GetComponent<Button>().onClick.Invoke();
        }

        //if (prewiew.activeInHierarchy)
        //{
        //    prewiewActive = true;
        //    prewiew.SetActive(!show);
        //}
        //else
        //{
        //    if (prewiewActive)
        //    {
        //        prewiew.SetActive(!show);
        //    }
        //    prewiewActive = false;
        //}

        //if (manual.activeInHierarchy)
        //{
        //    manual.SetActive(!show);
        //}
    }
}
