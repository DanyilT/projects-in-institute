﻿using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance;

    public AudioSource soundEffectsSource;
    public AudioSource musicSource;

    public AudioClip[] soundEffectsClip;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }

        SetSoundEffectsVolume(PlayerPrefs.GetFloat("SoundEffectsVolume", 0.5f));
        SetMusicVolume(PlayerPrefs.GetFloat("MusicVolume", 0.5f));
    }

    public void PlayButtonClick(int num)
    {
        soundEffectsSource.PlayOneShot(soundEffectsClip[num]);
    }

    public void SetSoundEffectsVolume(float volume)
    {
        soundEffectsSource.volume = volume;
        PlayerPrefs.SetFloat("SoundEffectsVolume", volume);
    }

    public void SetMusicVolume(float volume)
    {
        musicSource.volume = volume;
        PlayerPrefs.SetFloat("MusicVolume", volume);
    }
}
