﻿using System.Collections.Generic;
using Unity.VisualScripting.Antlr3.Runtime;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class ARSceneController : MonoBehaviour
{
    public ARRaycastManager raycastManager;
    public GameObject basketPrefab;
    public GameObject previewPanel;

    private GameObject spawnedBasket;

    private bool isPlaced = false;

    public PlaneDetectionController planeDetectionController;

    [SerializeField] private GameObject manual;
    [SerializeField] private GameObject maxScore;

    public bool manualActive;
    public bool maxScoreActive;

    private void Update()
    {
        // Show the previewPanel only when a plane is detected and the basket is not placed
        previewPanel.SetActive(planeDetectionController.IsPlaneDetected && !isPlaced);

        if(manual.activeInHierarchy)
        {
            previewPanel.SetActive(false);
        }

        if (maxScore.activeInHierarchy)
        {
            previewPanel.SetActive(false);
        }

        if (planeDetectionController.IsPlaneDetected && !isPlaced)
        {
            if (Input.touchCount > 0)
            {
                Touch touch = Input.GetTouch(0);
                if (touch.phase == TouchPhase.Began)
                {
                    Vector2 touchPosition = touch.position;
                    List<ARRaycastHit> hits = new List<ARRaycastHit>();
                    if (raycastManager.Raycast(touchPosition, hits, TrackableType.Planes))
                    {
                        Pose hitPose = hits[0].pose;
                        if (spawnedBasket == null)
                        {
                            spawnedBasket = Instantiate(basketPrefab, hitPose.position, basketPrefab.transform.rotation);
                            isPlaced = true;
                        }
                        else
                        {
                            spawnedBasket.transform.position = hitPose.position;
                        }
                    }
                }
            }
        }
    }
}
